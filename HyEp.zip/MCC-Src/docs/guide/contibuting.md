---
title: Contributing
---

# Contributing

At this moment this page needs to be created.

For now you can use our article from the [Git Hub repository Wiki](https://github.com/MCCTeam/Minecraft-Console-Client/wiki/Update-console-client-to-new-version) written by [ReinforceZwei](https://github.com/ReinforceZwei).

## Translations

To improve translations for MCC, please visit: [Crowdin - Minecraft Console Client](https://crwd.in/minecraft-console-client).

**It is recommended to translate `MCC in-app text` first.**

If you can't find the language you want to translate into, please contact us at Github or Discord to add it.

Github: <a href="https://github.com/MCCTeam/Minecraft-Console-Client" rel="nofollow noopener" target="_blank">https://github.com/MCCTeam/Minecraft-Console-Client</a>

Discord: <a href="https://discord.gg/9HPr2EE4C4" rel="nofollow noopener" target="_blank">https://discord.gg/9HPr2EE4C4</a>

## Contributors

[Check out our contributors on Github](https://github.com/MCCTeam/Minecraft-Console-Client/graphs/contributors).
