This part of the repository contains tools that may be useful for debugging

MinecraftClientProxy
 A proxy between a MCC/Vanilla client and an offline-mode server which can intercept packets
 Useful to dump packets sent by a Vanilla minecraft client and compare them with packets from MCC
 Example of use case: https://github.com/MCCTeam/Minecraft-Console-Client/issues/195
