﻿namespace MinecraftClient.Inventory
{
    /// <summary>
    /// Represents a Minecraft hand
    /// </summary>
    public enum Hand
    {
        MainHand = 0,
        OffHand = 1,
    }
}
