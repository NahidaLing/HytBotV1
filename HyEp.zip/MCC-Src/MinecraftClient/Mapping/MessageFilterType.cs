﻿namespace MinecraftClient.Mapping
{
    public enum MessageFilterType
    {
        PassThrough = 0,
        FullyFiltered,
        PartiallyFiltered
    }
}
