﻿namespace MinecraftClient.Mapping
{
    public enum InteractType
    {
        Interact = 0,
        Attack = 1,
        InteractAt = 2,
    }
}
