﻿namespace MinecraftClient.Mapping
{
    public enum CombatEventType
    {
        EnterCombat = 0,
        EndCombat,
        EntityDead
    }
}
