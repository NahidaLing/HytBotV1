﻿namespace MinecraftClient.Mapping
{
    public enum EntityPose
    {
        Standing = 0,
        FallFlying = 1,
        Sleeping = 2,
        Swimming = 3,
        SpinAttack = 4,
        Sneaking = 5,
        Dying = 6,
    }
}
